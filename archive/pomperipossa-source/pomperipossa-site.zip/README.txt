POMPERIPOSSA STATIC SITE

Files
index.html
cover.png

Deployment

1. Create a hidden folder or route on andreas-nyberg.com, for example:
   /pomperipossa/

2. Upload index.html and cover.png into that folder.

3. Visit:
   https://andreas-nyberg.com/pomperipossa/

The page has no external dependencies.

Read aloud
The "Läs högt" button uses the browser's built in Speech Synthesis API.
It will use a Swedish system voice when one is available.

If you later record the narration yourself, replace the browser voice control
with a normal HTML audio element pointing to your MP3 or WAV file.
